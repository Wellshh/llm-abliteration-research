"""Run a resumable V pilot with a locked model; all formal tests stay closed."""
from __future__ import annotations

import argparse
import json
import math
import os
import signal
import sys
import time
from contextlib import nullcontext
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from minicpm_research.evaluation import summarize
from minicpm_research.runs import PhaseBudget, RunStore, atomic_json, environment, file_hash, now, source_state
from minicpm_research.verifier import parse_verdict, validate_dataset


def validate_config(config: dict[str, Any]) -> None:
    if type(config.get("schema_version")) is not int or config["schema_version"] != 1:
        raise ValueError("Unsupported configuration schema")
    if config.get("stage") != "T04" or config.get("split") != "pilot":
        raise ValueError("Only T04 pilot is enabled; formal splits are sealed")
    if config.get("condition") not in {"baseline", "identity_hook"}:
        raise ValueError("Only baseline/identity control is enabled before intervention selection")
    if config.get("dtype") != "bfloat16" or config.get("attention_backend") not in {"eager", "sdpa"}:
        raise ValueError("Primary precision must be bfloat16 with an explicit eager/sdpa backend")
    for key, maximum in {"max_prompt_tokens": 2048, "max_new_tokens": 128, "chunk_size": 100, "cpu_threads": 4}.items():
        value = config.get(key)
        if type(value) is not int or not 0 < value <= maximum:
            raise ValueError(f"Invalid or over-budget setting: {key}")
    for key, maximum in {"budget_gib": 32, "max_gpu_hours": 5}.items():
        value = config.get(key)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 < value <= maximum:
            raise ValueError(f"Invalid or over-budget setting: {key}")
    if type(config.get("seed")) is not int or not 0 <= config["seed"] < 2**63:
        raise ValueError("seed must be a nonnegative 63-bit integer")
    if type(config.get("reserve_gib")) is not int or config["reserve_gib"] != 12:
        raise ValueError("The minimum full-card reserve is fixed at 12 GiB")
    from minicpm_research.resources import AUTHORIZED_GPUS
    if config.get("gpu_uuid") not in AUTHORIZED_GPUS:
        raise ValueError("gpu_uuid must explicitly select one authorized device")


def select_pilot(examples: list[dict[str, Any]], max_families: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if type(max_families) is not int or max_families <= 0:
        raise ValueError("max-families must be a positive integer")
    if any(example.get("split") != "pilot" for example in examples):
        raise ValueError("Refusing non-pilot input before gold verification or selection")
    validation = validate_dataset(examples)
    family_ids = list(dict.fromkeys(e["family_id"] for e in examples if e["task"] == "V"))[:max_families]
    selected = [e for e in examples if e["task"] == "V" and e["family_id"] in family_ids]
    if not selected:
        raise ValueError("No V pilot examples selected")
    return selected, validation


def validate_saved_rows(store: RunStore, selected: list[dict[str, Any]]) -> None:
    expected = {example["example_id"]: example for example in selected}
    for key, row in store.rows.items():
        if key not in expected or any(row.get(field) != expected[key][field] for field in ("family_id", "task", "gold")):
            raise ValueError("Completed output does not match the selected sample and gold")


def write_summary(store: RunStore, selected: list[dict[str, Any]], gpu_execution: bool) -> dict[str, Any]:
    validate_saved_rows(store, selected)
    report = summarize(list(store.rows.values()))
    report.update({"run_id": store.run_id, "gpu_execution": gpu_execution, "finished_at": now(),
                   "planned_examples": len(selected), "completed_examples": len(store.rows),
                   "complete": len(store.rows) == len(selected),
                   "metric_denominator": "all_durable_model_or_protocol_outputs; unproduced infrastructure failures excluded and counted separately",
                   "unproduced_examples": len(selected) - len(store.rows)})
    atomic_json(store.path / "PILOT_BASELINE.json", report)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=ROOT / "configs/pilot.json")
    parser.add_argument("--data", type=Path, default=ROOT / "artifacts/data/pilot.jsonl")
    parser.add_argument("--model-lock", type=Path, default=ROOT / "artifacts/model/MODEL_MANIFEST.json")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "artifacts/runs")
    parser.add_argument("--device", choices=("cpu", "cuda:0"), default="cuda:0")
    parser.add_argument("--max-families", type=int, default=12, help="whole V families, in deterministic file order")
    parser.add_argument("--dry-run", action="store_true", help="validate inputs without a model or any model metrics")
    args = parser.parse_args()
    config = json.loads(args.config.read_text(encoding="utf-8"))
    validate_config(config)
    examples = [json.loads(line) for line in args.data.read_text(encoding="utf-8").splitlines() if line.strip()]
    selected, validation = select_pilot(examples, args.max_families)
    if args.dry_run:
        print(json.dumps({"mode": "dry_run", "validation": validation, "selected_V_examples": len(selected),
                          "selected_V_families": len({e["family_id"] for e in selected}), "model_inference": "未运行", "gpu_execution": "未运行",
                          "T_model_evaluation": "blocked_pending_native_parser_validation", "metrics": None}, ensure_ascii=False))
        return 0
    manifest = {"schema_version": 1, "config": config, "device": args.device,
                "selected_example_ids": [e["example_id"] for e in selected], "data_sha256": file_hash(args.data),
                "model_manifest_sha256": file_hash(args.model_lock), "source": source_state(ROOT), "environment": environment(),
                "T_model_evaluation": "not_run_pending_native_parser", "intervention": {"condition": config["condition"], "weights_mutated": False}}
    from minicpm_research.resources import (ResourceError, RuntimeResourceGuard, audit_resources,
        capture_snapshot, require_admission, research_lock_path, single_worker_lock)
    # CPU runs use the same Linux lock so the same manifest never has two writers.
    if sys.platform != "linux":
        raise ValueError("Model runs are supported on the Linux research server; local dry-run is portable")
    with single_worker_lock(research_lock_path()):
        store = RunStore(args.output_dir, manifest)
        validate_saved_rows(store, selected)
        gpu_execution = args.device == "cuda:0" and any("raw_token_ids" in row for row in store.rows.values())
        if len(store.rows) == len(selected):
            write_summary(store, selected, gpu_execution)
            print(json.dumps({"status": "already_complete", "run_id": store.run_id, "path": str(store.path)}))
            return 0
        stop = {"requested": False}
        def request_stop(signum: int, frame: Any) -> None:
            stop["requested"] = True
        signal.signal(signal.SIGTERM, request_stop)
        signal.signal(signal.SIGINT, request_stop)
        started = time.monotonic()
        attempt = f"{time.time_ns()}-{os.getpid()}"
        store.event("attempt_started", attempt=attempt, pid=os.getpid(), requested_device=args.device, gpu_execution=False)
        admission = None
        budget = None
        guard = None
        guard_started = False
        model = None
        active_example_id = None
        pending: list[dict[str, Any]] = []
        try:
            if args.device == "cuda:0":
                audit = audit_resources(store.path / f"audit-{attempt}", seconds=60)
                if stop["requested"]:
                    raise ResourceError("Stop requested during audit; model loading was not started")
                admission = require_admission(audit, config["gpu_uuid"], config["budget_gib"], ROOT / "artifacts/reservation")
                os.environ.update(admission["cuda_environment"])
                atomic_json(store.path / f"admission-{attempt}.json", admission)
                budget = PhaseBudget(ROOT / "artifacts/budgets/phase0_gpu_budget.json", config["max_gpu_hours"] * 3600)
                budget.start(attempt, store.run_id)
            else:
                atomic_json(store.path / f"cpu-audit-{attempt}.json", capture_snapshot(ROOT))
            guard = RuntimeResourceGuard(ROOT, admission=admission, event_sink=store.event, budget=budget)
            guard.__enter__()
            guard_started = True
            os.environ["OMP_NUM_THREADS"] = str(config["cpu_threads"])
            os.environ["TOKENIZERS_PARALLELISM"] = "false"
            import torch
            torch.set_num_threads(config["cpu_threads"])
            torch.manual_seed(config["seed"])
            if admission:
                if torch.cuda.device_count() != 1:
                    raise ResourceError("Expected exactly one visible GPU")
                properties = torch.cuda.get_device_properties(0)
                actual_uuid = str(getattr(properties, "uuid", ""))
                if actual_uuid.removeprefix("GPU-") != config["gpu_uuid"].removeprefix("GPU-"):
                    raise ResourceError("CUDA runtime UUID differs from admitted UUID")
                torch.cuda.set_per_process_memory_fraction(admission["budget_bytes"] / properties.total_memory, 0)
            from minicpm_research.model import load_locked_model, render_prompt, token_anchors
            from minicpm_research.hooks import PostBlockHooks
            model, tokenizer = load_locked_model(args.model_lock, device=args.device, dtype=config["dtype"], attention_backend=config["attention_backend"])
            guard.model_loaded = True
            guard.sample()
            from transformers import StoppingCriteria, StoppingCriteriaList
            class ResourceBoundary(StoppingCriteria):
                def __call__(self, input_ids: Any, scores: Any, **kwargs: Any) -> bool:
                    guard.check()
                    return False
            atomic_json(store.path / "TOKEN_ANCHORS.json", [token_anchors(tokenizer, e["messages"]) for e in selected[:24]])
            last_check = time.monotonic()
            for example in selected:
                if example["example_id"] in store.rows:
                    continue
                active_example_id = example["example_id"]
                guard.check()
                if stop["requested"] or time.monotonic() - started >= config["max_gpu_hours"] * 3600:
                    store.commit(pending)
                    pending = []
                    guard_started = False
                    guard.__exit__(None, None, None)
                    write_summary(store, selected, gpu_execution)
                    store.event("stopped_at_boundary", reason="signal_or_time_budget")
                    return 3
                prompt = render_prompt(tokenizer, example["messages"])
                encoded = tokenizer(prompt, add_special_tokens=False, return_tensors="pt")
                length = encoded["input_ids"].shape[-1]
                if length > config["max_prompt_tokens"]:
                    # No silent prompt truncation; this is a retained protocol failure.
                    row = {"example_id": example["example_id"], "family_id": example["family_id"], "task": "V", "gold": example["gold"],
                           "raw_text": "", "parsed": {"status": "PROMPT_TOO_LONG", "semantic_label": None}, "prompt_tokens": length}
                else:
                    encoded = {key: tensor.to(args.device) for key, tensor in encoded.items()}
                    timer = time.monotonic()
                    context = PostBlockHooks(model) if config["condition"] == "identity_hook" else nullcontext()
                    with torch.inference_mode(), context:
                        gpu_execution = args.device == "cuda:0"
                        output = model.generate(**encoded, do_sample=False, max_new_tokens=config["max_new_tokens"], use_cache=True,
                                                pad_token_id=tokenizer.pad_token_id,
                                                stopping_criteria=StoppingCriteriaList([ResourceBoundary()]))
                    generated = output[0, length:].tolist()
                    seconds = time.monotonic() - timer
                    eos = model.generation_config.eos_token_id
                    eos_ids = eos if isinstance(eos, list) else [eos]
                    truncated = len(generated) >= config["max_new_tokens"] and (not generated or generated[-1] not in eos_ids)
                    text = tokenizer.decode(generated, skip_special_tokens=True)
                    row = {"example_id": example["example_id"], "family_id": example["family_id"], "task": "V", "gold": example["gold"],
                           "raw_text": text, "raw_token_ids": generated, "parsed": parse_verdict(text, example["label_map"], truncated=truncated),
                           "prompt_tokens": length, "generated_tokens": len(generated), "generation_seconds": seconds}
                store.event("raw_result", attempt=attempt, row=row)
                pending.append(row)
                active_example_id = None
                if len(pending) >= config["chunk_size"] or time.monotonic() - last_check >= 30:
                    store.commit(pending)
                    pending = []
                    guard.sample()
                    last_check = time.monotonic()
            store.commit(pending)
            pending = []
            guard.check()
            guard_started = False
            guard.__exit__(None, None, None)
            write_summary(store, selected, gpu_execution)
            store.event("attempt_completed", attempt=attempt, examples=len(store.rows), gpu_execution=gpu_execution, elapsed_seconds=time.monotonic() - started)
            print(json.dumps({"status": "complete", "run_id": store.run_id, "path": str(store.path), "examples": len(store.rows)}))
            return 0
        except BaseException as exc:
            # Completed outputs are retained even when a later sample or
            # resource check fails. Infrastructure failure is not ABSTAIN.
            store.event("attempt_failed", attempt=attempt, example_id=active_example_id, gpu_execution=gpu_execution,
                        error_type=type(exc).__name__, error=str(exc), elapsed_seconds=time.monotonic() - started)
            store.commit(pending)
            pending = []
            write_summary(store, selected, gpu_execution)
            atomic_json(store.path / f"failure-{attempt}.json", {"status": "failed", "error_type": type(exc).__name__, "error": str(exc),
                        "example_id": active_example_id, "gpu_execution": gpu_execution, "completed_examples": len(store.rows)})
            raise
        finally:
            try:
                if guard_started:
                    guard.__exit__(*sys.exc_info())
            finally:
                model = None
                if admission and "torch" in locals():
                    torch.cuda.empty_cache()
                if budget is not None:
                    budget.checkpoint(finish=True)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, RuntimeError) as error:
        print(f"pilot failed: {error}", file=sys.stderr)
        raise SystemExit(1)
