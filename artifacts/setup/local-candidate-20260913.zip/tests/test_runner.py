"""CPU-only run persistence, denominator and resource failure regression tests."""
from __future__ import annotations

import copy
import importlib.util
import json
import os
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from minicpm_research import resources
from minicpm_research.data import build_pilot
from minicpm_research.runs import PhaseBudget, RunStore, atomic_json, digest

spec = importlib.util.spec_from_file_location("pilot_runner_under_test", ROOT / "scripts/run_pilot.py")
assert spec is not None and spec.loader is not None
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)


def result_row(example: dict, status: str = "VALID") -> dict:
    return {key: example[key] for key in ("example_id", "family_id", "task", "gold")} | {
        "raw_text": "synthetic test output", "parsed": {"status": status,
            "semantic_label": example["gold"] if status == "VALID" else None}}


class RunnerProtocolTests(unittest.TestCase):
    def test_config_rejects_coercion_and_forbidden_devices(self) -> None:
        config = json.loads((ROOT / "configs/pilot.json").read_text(encoding="utf-8"))
        runner.validate_config(config)
        for key in ("schema_version", "max_prompt_tokens", "max_new_tokens", "chunk_size", "cpu_threads", "seed", "reserve_gib"):
            for bad in (True, float(config[key])):
                with self.subTest(key=key, bad=bad), self.assertRaises(ValueError):
                    runner.validate_config(config | {key: bad})
        for key, bad in (("seed", -1), ("seed", 2**63), ("gpu_uuid", "GPU-unapproved"),
                         ("budget_gib", 33), ("max_gpu_hours", 6), ("budget_gib", True),
                         ("max_gpu_hours", float("nan")), ("split", "test_A")):
            with self.subTest(key=key, bad=bad), self.assertRaises(ValueError):
                runner.validate_config(config | {key: bad})

    def test_selection_rejects_sealed_input_before_verifier_and_keeps_families(self) -> None:
        with patch.object(runner, "validate_dataset") as verifier:
            with self.assertRaisesRegex(ValueError, "before gold verification"):
                runner.select_pilot([{"split": "test_A"}], 1)
            verifier.assert_not_called()
        examples = build_pilot(3, 4, 1)
        selected, validation = runner.select_pilot(examples, 2)
        self.assertEqual(len(selected), 6)
        self.assertEqual(validation["examples"], 16)
        self.assertEqual(len({row["family_id"] for row in selected}), 2)
        self.assertEqual({row["task"] for row in selected}, {"V"})
        for bad in (True, 1.5, 0):
            with self.assertRaises(ValueError):
                runner.select_pilot(examples, bad)

    def test_summary_failure_denominators_and_unproduced_are_separate(self) -> None:
        selected = build_pilot(2, 2, 0)
        with tempfile.TemporaryDirectory() as temporary:
            store = RunStore(Path(temporary), {"test": "summary"})
            store.commit([result_row(example, status) for example, status in zip(selected,
                ("VALID", "INVALID", "TRUNCATED", "PROMPT_TOO_LONG"))])
            summary = runner.write_summary(store, selected, False)
            self.assertEqual(summary["metrics"]["V"]["total"], 4)
            self.assertEqual(summary["metrics"]["V"]["accuracy"], .25)
            self.assertEqual(summary["metrics"]["V"]["parse_valid_rate"], .25)
            self.assertEqual(summary["unproduced_examples"], 2)
            self.assertFalse(summary["complete"])
            for status in ("INVALID", "TRUNCATED", "PROMPT_TOO_LONG"):
                self.assertEqual(summary["metrics"]["V"][status], 1)
            self.assertTrue((store.path / "PILOT_BASELINE.json").exists())


class RunPersistenceTests(unittest.TestCase):
    def test_uncommitted_durable_row_recovers_and_incomplete_tail_stays_untouched(self) -> None:
        row = result_row(build_pilot(1, 1, 0)[0])
        with tempfile.TemporaryDirectory() as temporary:
            base, manifest = Path(temporary), {"test": "recovery"}
            original = RunStore(base, manifest)
            original.event("raw_result", row=row)
            event_file = next(original.path.glob("events-*.jsonl"))
            event = json.loads(event_file.read_text(encoding="utf-8"))
            self.assertEqual(event["row_sha256"], digest(row))
            with event_file.open("ab") as handle:
                handle.write(b'{"interrupted":')
            original_bytes = event_file.read_bytes()
            resumed = RunStore(base, manifest)
            self.assertEqual(resumed.rows, {row["example_id"]: row})
            resumed.event("test_resume_event")
            self.assertEqual(event_file.read_bytes(), original_bytes)
            self.assertGreaterEqual(len(list(original.path.glob("events-*.jsonl"))), 2)
            self.assertEqual(RunStore(base, manifest).rows, resumed.rows)

    def test_duplicate_commits_and_conflicting_raw_outputs_fail(self) -> None:
        row = result_row(build_pilot(1, 1, 0)[0])
        with tempfile.TemporaryDirectory() as temporary:
            base, manifest = Path(temporary), {"test": "conflicts"}
            store = RunStore(base, manifest)
            with self.assertRaisesRegex(ValueError, "duplicate"):
                store.commit([row, row])
            store.commit([row])
            with self.assertRaisesRegex(ValueError, "duplicate"):
                store.commit([row])
            store.event("raw_result", row=row | {"raw_text": "different output"})
            with self.assertRaisesRegex(ValueError, "Conflicting durable"):
                RunStore(base, manifest)

    def test_corrupt_durable_hash_and_interior_log_line_fail(self) -> None:
        for corrupt_hash in (True, False):
            with self.subTest(corrupt_hash=corrupt_hash), tempfile.TemporaryDirectory() as temporary:
                base, manifest = Path(temporary), {"test": "corrupt"}
                store = RunStore(base, manifest)
                if corrupt_hash:
                    row = result_row(build_pilot(1, 1, 0)[0])
                    payload = json.dumps({"event": "raw_result", "row": row, "row_sha256": "bad"}).encode() + b"\n"
                else:
                    payload = b'not json\n{"event":"later"}\n'
                (store.path / "events-corrupt.jsonl").write_bytes(payload)
                with self.assertRaisesRegex(ValueError, "Corrupt"):
                    RunStore(base, manifest)


class PhaseBudgetTests(unittest.TestCase):
    def test_finished_attempt_freezes_and_cross_run_budget_accumulates(self) -> None:
        with tempfile.TemporaryDirectory() as temporary, patch("minicpm_research.runs.time.monotonic") as monotonic:
            path = Path(temporary) / "budget.json"
            monotonic.return_value = 100.0
            first = PhaseBudget(path, 100)
            first.start("attempt-one", "run-one")
            monotonic.return_value = 130.0
            self.assertEqual(first.checkpoint(finish=True), 30)
            monotonic.return_value = 150.0
            self.assertEqual(first.remaining_seconds(), 70)
            second = PhaseBudget(path, 100)
            self.assertEqual(second.remaining_seconds(), 70)
            second.start("attempt-two", "run-two")
            monotonic.return_value = 170.0
            self.assertEqual(second.checkpoint(finish=True), 50)
            self.assertEqual(PhaseBudget(path, 100).remaining_seconds(), 50)
            self.assertEqual([item["run_id"] for item in second.state["attempts"]], ["run-one", "run-two"])

    def test_orphan_is_charged_conservatively_and_never_claimed_measured(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "budget.json"
            started = (datetime.now(timezone.utc) - timedelta(seconds=40)).isoformat()
            atomic_json(path, {"schema_version": 1, "stage": "P0", "attempts": [{"attempt_id": "orphan", "run_id": "old-run",
                "status": "running", "started_at": started, "charged_seconds": 7,
                "charge_is_measured_gpu_runtime": True}]})
            budget = PhaseBudget(path, 30)
            self.assertGreaterEqual(budget.charged_seconds, 40)
            self.assertEqual(budget.state["attempts"][0]["status"], "orphaned_conservative_charge")
            self.assertFalse(budget.state["attempts"][0]["charge_is_measured_gpu_runtime"])
            with self.assertRaisesRegex(RuntimeError, "exhausted"):
                budget.start("next", "next-run")


class RuntimeGuardTests(unittest.TestCase):
    def test_lock_path_is_host_local_and_independent_of_tmpdir(self) -> None:
        with patch.object(resources.sys, "platform", "linux"), patch.object(resources.os, "getuid", return_value=1001, create=True), patch.dict(os.environ, {"TMPDIR": "/unrelated/path"}):
            self.assertEqual(resources.research_lock_path().as_posix(), "/tmp/minicpm5-refusal-decision-1001.lock")

    def test_memory_thresholds_and_missing_telemetry_fail_closed(self) -> None:
        gib, uuid = resources.GIB, resources.PRIMARY_GPU_UUID
        admission = {"gpu_uuid": uuid, "physical_index": 3, "reserve_bytes": 12*gib, "budget_bytes": 32*gib}
        snapshot = {"host": {"disk_free_bytes": 20*gib}, "errors": [],
            "gpus": [{"uuid": uuid, "index": 3, "memory_free_bytes": 12*gib}],
            "processes": [{"pid": os.getpid(), "gpu_uuid": uuid, "used_gpu_memory_bytes": 32*gib}]}
        memory = {"rss_bytes": 32*gib, "peak_rss_bytes": 32*gib}
        with tempfile.TemporaryDirectory() as temporary:
            def sample(current: dict, own_memory: dict) -> dict:
                guard = resources.RuntimeResourceGuard(Path(temporary), admission=admission)
                guard.model_loaded = True
                with patch.object(resources, "capture_snapshot", return_value=copy.deepcopy(current)), patch.object(resources, "process_memory_bytes", return_value=own_memory):
                    return guard.sample()
            self.assertEqual(sample(snapshot, memory)["own_process_memory"], memory)
            bad_cases = []
            over_gpu = copy.deepcopy(snapshot)
            over_gpu["processes"][0]["used_gpu_memory_bytes"] += 1
            bad_cases.append((over_gpu, memory))
            low_free = copy.deepcopy(snapshot)
            low_free["gpus"][0]["memory_free_bytes"] -= 1
            bad_cases.append((low_free, memory))
            unknown = copy.deepcopy(snapshot)
            unknown["processes"][0]["used_gpu_memory_bytes"] = None
            bad_cases.append((unknown, memory))
            absent = copy.deepcopy(snapshot)
            absent["processes"] = []
            bad_cases.append((absent, memory))
            bad_cases.append((snapshot, memory | {"rss_bytes": 32*gib+1}))
            bad_cases.append((snapshot, memory | {"peak_rss_bytes": 32*gib+1}))
            for index, (current, own_memory) in enumerate(bad_cases):
                with self.subTest(case=index), self.assertRaises(resources.ResourceError):
                    sample(current, own_memory)


if __name__ == "__main__":
    unittest.main()
