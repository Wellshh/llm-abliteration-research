LOCAL CANDIDATE 2026-09-13

This package contains read-only copies from E:\minicpm-research for remote review.
The scripts/run_pilot.py copy is V-only T04 comparison code and MUST NOT overwrite a remote T-enabled runner.
No model/GPU execution, SSH, or source edits were performed while preparing this package.
See LOCAL_CANDIDATE_MANIFEST.json for per-file SHA256 and provenance.
